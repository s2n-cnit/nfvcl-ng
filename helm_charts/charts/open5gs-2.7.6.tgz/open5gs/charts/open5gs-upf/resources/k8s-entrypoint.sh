#!/bin/bash
set -e

echo "Executing k8s customized entrypoint.sh"

{{- range .Values.config.subnetList }}
echo "Creating net device {{ .dev }}"
if ! grep "{{ .dev }}" /proc/net/dev > /dev/null; then
    ip tuntap add name {{ .dev }} mode tun
else
    echo "Net device {{ .dev }} already exists, skipping creation"
fi
ip link set {{ .dev }} up
ip link set dev {{ .dev }} txqueuelen 4096
echo "Setting IP {{ .gateway }} to device {{ .dev }}"
ip addr add {{ .gateway }}/{{ .mask }} dev {{ .dev }};
sysctl -w net.ipv4.ip_forward=1;
{{- if .enableNAT }}
echo "Enable NAT for {{ .subnet }} and device {{ .dev }}"
iptables -t nat -A POSTROUTING -s {{ .subnet }} ! -o {{ .dev }} -j MASQUERADE;
{{- end }}
{{- end }}

{{- if $.Values.multus.n6network.enabled }}
echo "1200 n6if" >> /etc/iproute2/rt_tables
ip route replace {{ $.Values.config.upf.gnbSubnet }} via {{ $.Values.multus.n3network.gatewayIP }} dev {{ $.Values.multus.n3network.interfaceName }}
ip route replace default via {{ $.Values.multus.n6network.gatewayIP }} dev {{ $.Values.multus.n6network.interfaceName }} table n6if
{{- range $.Values.config.subnetList }}
ip rule add iif {{ .dev }} lookup n6if
{{- end }}
{{- end }}

$@